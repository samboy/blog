I have seen people express a desire for Zillions to support
a simple "Newspaper" look.  This is a version of Chess that
uses an adaption of a chess font designed for newspapers and
other places where design using only black and white which can
easily be printed is desired.

Chess, along with a few different Chess18 (or Chess960) setups is
provided. We also have the four "Energizer" setups proposed by Sibahi
(setups where there are rook + knight and bishop + knight fairy pieces
on an 8x8 board), as well as three 10x8 setups (Capablanca Chess).

Screenshots of Zillions using this rule file can easily be printed
with a black and white printer, but for more resolution there is also 
included a font for making Chess diagrams that can be printed, even 
with black and white laser printers.  This font, which is public domain, 
is the redrawing of a classic 20th century diagram font.

The font has two fairy pieces: A rook + knight fairy piece, and
a bishop + knight fairy piece.  Here is how the opening position
in Classic chess would look using this font:

!""""""""#
$tMvWlVmT%
$OoOoOoOo%
$ + + + +%
$+ + + + %
$ + + + +%
$+ + + + %
$pPpPpPpP%
$RnBqKbNr%
/(((((((()

Upper case letters are pieces on dark squares; lower case letters
and pieces on light squares.  The pieces are as follows:

R: White Rook
T: Black Rook
N: White Knight
M: Black Knight
B: White Bishop
V: Black Bishop
Q: White Queen
W: Black Queen
K: White King
L: Black King
P: White Pawn
O: Black Pawn

Support for two fairy pieces is also provided:

A: White Archbishop (Knight + Bishop)
S: Black Archbishop
D: White Marshal (Knight + Rook)
F: Black Marshal

A space is an empty white square; a '+' is an empty black square.

The top left corner is a '!'; the top is a '"'; the top right corner
is a '#', left side is a '$', the right side is a '%', the bottom
left corner is a '/', the bottom is a '(', and the bottom right corner
is a ')'.

